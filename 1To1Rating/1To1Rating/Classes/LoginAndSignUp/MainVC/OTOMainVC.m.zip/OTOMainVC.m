//
//  OTOMainVC.m
//  1To1Rating
//
//  Created by Saurabh Vaza on 17/08/17.
//  Copyright © 2017 Ganadhakshya. All rights reserved.
//

#import "OTOMainVC.h"
#import <AccountKit/AccountKit.h>


@interface OTOMainVC ()<AKFViewControllerDelegate>
{
    
    __weak IBOutlet UIImageView *imgViewBg;
    __weak IBOutlet UIImageView *imgViewRating;
    
    __weak IBOutlet UIButton *btnLoginWithEmail;
    
    __weak IBOutlet UIButton *btnLoginWithFb;
    __weak IBOutlet UIButton *btnSignUp;
    __weak IBOutlet UILabel *lblCntTermsAndPolicy;
    
    
    AKFAccountKit *accountKit;
    UIViewController<AKFViewController> *objPendingLoginVC;
    NSString *strAuthorizationCode;
    
}
@end

@implementation OTOMainVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setUpView];
    [self setUpBasic];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if ([self isUserLoggedIn]) {
        // if the user is already logged in, go to the main screen
        [self proceedToMainScreen];
    } else if (objPendingLoginVC != nil) {
        // resume pending login (if any)
        [self _prepareLoginViewController:objPendingLoginVC];
        [self presentViewController:objPendingLoginVC
                           animated:animated
                         completion:NULL];
        objPendingLoginVC = nil;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark -----------
#pragma mark 

- (void)setUpView{
    
    btnLoginWithFb.clipsToBounds = YES;
    btnLoginWithEmail.clipsToBounds = YES;
    
    btnLoginWithEmail.layer.cornerRadius = 5.0;
    btnLoginWithFb.layer.cornerRadius = 5.0;
    
    [btnLoginWithFb setImageEdgeInsets:UIEdgeInsetsMake(0, -10, 0, 10)];
    [btnLoginWithFb setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -15)];
    
    [btnLoginWithEmail setImageEdgeInsets:UIEdgeInsetsMake(0, -47, 0, 10)];
    [btnLoginWithEmail setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 20)];

}

- (void)setUpBasic{
    
    // initialize Account Kit
    if (accountKit == nil) {
        // may also specify AKFResponseTypeAccessToken
        accountKit = [[AKFAccountKit alloc] initWithResponseType:AKFResponseTypeAuthorizationCode];
    }
    
    // view controller for resuming login
    objPendingLoginVC = [accountKit viewControllerForLoginResume];
    
}

#pragma mark -----------
#pragma mark User Define Titles

- (IBAction)btnLoginWithEmailClicked:(id)sender {
    
    
}

- (IBAction)btnLoginWithFBClicked:(id)sender {
    NSString *inputState = [[NSUUID UUID] UUIDString];
    UIViewController<AKFViewController> *viewController = [accountKit viewControllerForEmailLoginWithEmail:nil
                                                                                                      state:inputState];
    [self _prepareLoginViewController:viewController]; // see below
    [self presentViewController:viewController animated:YES completion:NULL];
    
}
- (IBAction)btnSignUpClicked:(id)sender {
}

#pragma mark -----------
#pragma mark Other Methods{

- (BOOL) isUserLoggedIn{
    if ([accountKit currentAccessToken]) {
        return YES;
    }
    return NO;
}


- (void)proceedToMainScreen{
    
    
    AKFAccountKit *accountKit = [[AKFAccountKit alloc] initWithResponseType:AKFResponseTypeAccessToken];
    [accountKit requestAccount:^(id<AKFAccount> account, NSError *error) {
        // account ID
        NSLog(@"account.accountID :: %@",account.accountID);
        //self.accountIDLabel.text = account.accountID;
        if ([account.emailAddress length] > 0) {
            //self.titleLabel.text = @"Email Address";
//            self.valueLabel.text = account.emailAddress;
            NSLog(@"account.emailAddress :: %@",account.emailAddress);
        }
        else if ([account phoneNumber] != nil) {
//            self.titleLabel.text = @"Phone Number";
//            self.valueLabel.text = [[account phoneNumber] stringRepresentation];
            NSLog(@"account.phoneNumber :: %@",[[account phoneNumber] stringRepresentation]);

        }
    }];
    
}

#pragma mark -----------
#pragma mark 

- (void)_prepareLoginViewController:(UIViewController<AKFViewController> *)loginViewController
{
    loginViewController.delegate = self;
    // Optionally, you may use the Advanced UI Manager or set a theme to customize the UI.
    loginViewController.advancedUIManager = nil;
    loginViewController.theme = nil;//[Themes bicycleTheme];
}

#pragma mark -----------
#pragma mark AKFViewController Delegate Methods

- (void)viewController:(UIViewController<AKFViewController> *)viewController didCompleteLoginWithAuthorizationCode:(NSString *)code state:(NSString *)state{
    
    // Pass the code to your own server and have your server exchange it for a user access token.
    // You should wait until you receive a response from your server before proceeding to the main screen.
//    [self sendAuthorizationCodeToServer:code];
    [self proceedToMainScreen];

}

- (void)viewController:(UIViewController<AKFViewController> *)viewController didCompleteLoginWithAccessToken:(id<AKFAccessToken>)accessToken state:(NSString *)state{
    [self proceedToMainScreen];
}

- (void)viewController:(UIViewController<AKFViewController> *)viewController didFailWithError:(NSError *)error{
    // ... implement appropriate error handling ...
    NSLog(@"%@ did fail with error: %@", viewController, error);
}

- (void)viewControllerDidCancel:(UIViewController<AKFViewController> *)viewController{
    
}

@end
